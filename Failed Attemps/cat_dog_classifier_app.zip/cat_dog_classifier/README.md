# Image Classifier Application

A modern, user-friendly desktop application for binary image classification using TensorFlow models. Built with PySide6 and featuring a dark theme interface.

## Features

- Modern dark theme UI with clean, intuitive controls
- Support for loading custom TensorFlow models (.h5 format)
- Adjustable input image dimensions
- Configurable classification threshold
- Real-time confidence visualization
- Error handling and user feedback

## Installation

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Linux/Mac
# or
venv\Scripts\activate  # On Windows
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Running the Application

1. Make sure your virtual environment is activated
2. Run the application:
```bash
python app.py
```

## Using Your Own Model

The application works with TensorFlow binary classification models that:

1. Accept a single image input
2. Output a single probability value between 0 and 1
3. Are saved in the `.h5` format

To use your model:

1. Click "Load Model" and select your `.h5` file
2. Set the input dimensions to match your model's expected input size
3. Click "Load Image" to select an image for classification
4. Adjust the threshold slider if needed (default: 50%)
5. Click "Predict" to run the classification

The result will show as "Positive" or "Negative" along with the confidence percentage.

## Notes

- The application automatically normalizes input images to the range [0,1]
- Make sure your model expects normalized input images
- The default input size is 224x224 pixels, but this can be adjusted through the UI
- The threshold slider determines the cutoff between positive and negative classifications

## Supported Formats

### Models
- TensorFlow SavedModel format (directory)
- TensorFlow .h5 model files
- Expected input shape: [batch_size, height, width, 3]
- Expected output: 2 classes (Cat/Dog) with softmax probabilities

### Images
- JPEG (.jpg, .jpeg)
- PNG (.png)
- Images will be automatically resized to model's input dimensions

### Labels
- Default labels: ["Cat", "Dog"]
- Optional: Load custom labels from labels.txt or labels.json

## Preprocessing Parameters

- Image dimensions (width/height)
- Normalization options:
  - Mean/Std normalization
  - Min/Max scaling (0-1 or -1 to 1)

## Error Handling

The application provides clear error messages for:
- Invalid image formats
- Incompatible model formats
- Incorrect model input/output shapes
- Memory or processing errors 